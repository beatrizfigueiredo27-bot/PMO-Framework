PMI Predictive Project Management Toolkit (PMBOK Guide - 8th Edition aligned)
=============================================================================
Regenerate all 25 artefacts with YOUR project metadata:

1. Install Python 3.10+ and:  pip install python-docx openpyxl python-pptx
2. Edit config.py -> PROJECT block (organization, project name, ID, sponsor, PM,
   dates, currency, classification) and DOC_DEFAULTS (version/status/date).
3. Run:  python build_toolkit.py "My Project Toolkit"
4. Open each .xlsx once in Excel (formulas calculate on open) and update the
   Table of Contents in each .docx (right-click > Update Field).

Files:  config.py (metadata, register, versioning, glossary, brand)
        docx_kit.py / xlsx_kit.py (shared document-control & styling engines)
        docs_word_a.py, docs_word_b.py (Word plans), books_a.py, books_b.py
        (Excel registers), deck.py (status report deck)
