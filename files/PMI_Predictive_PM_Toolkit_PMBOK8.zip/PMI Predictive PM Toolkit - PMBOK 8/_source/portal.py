"""Assemble the PMO Documentation Framework portal (single self-contained HTML)."""
import base64, json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import PROJECT, DOC_DEFAULTS, DOMAINS, FOCUS_AREAS, GLOSSARY, VERSIONING, PRINCIPLES, doc_id
from framework import artefacts, GATES, CATS, AUTHORITY, ESCALATION, RAG, DOC_STANDARD

src_dir, out = sys.argv[1], sys.argv[2]
arts = artefacts()
data = dict(
    project=PROJECT, version=DOC_DEFAULTS["version"], status=DOC_DEFAULTS["status"],
    artefacts=arts, domains=DOMAINS, focus=FOCUS_AREAS, principles=PRINCIPLES,
    gates=[dict(id=g[0], name=g[1], fa=g[2], appr=g[3], crit=g[4]) for g in GATES],
    cats=CATS, authority=AUTHORITY, escalation=ESCALATION, rag=RAG, docStandard=DOC_STANDARD,
    glossary=GLOSSARY, versioning=VERSIONING,
    meta={"Organization": PROJECT["org"], "Project name": PROJECT["name"], "Project ID": PROJECT["id"],
          "Sponsor": PROJECT["sponsor"], "Project Manager": PROJECT["pm"], "PMO / Portfolio": PROJECT["pmo"],
          "Planned start / finish": f"{PROJECT['start']} / {PROJECT['finish']}", "Currency": PROJECT["currency"],
          "Delivery approach": PROJECT["approach"], "Classification": PROJECT["classification"]},
)
files = {"list": [], "data": {}}
for name in sorted(os.listdir(src_dir)):
    p = os.path.join(src_dir, name)
    if not os.path.isfile(p) or not name.split(".")[-1] in ("docx", "xlsx", "pptx"):
        continue
    m = re.match(r"(\d\d) — (.+)\.(\w+)$", name)
    no, label, ext = m.group(1), m.group(2), m.group(3)
    raw = open(p, "rb").read()
    entry = dict(name=name, label=label + (" (Word)" if no == "22" and ext == "docx" else ""), ext=ext, size=len(raw),
                 no=None if no == "00" else no)
    if no == "00":
        entry["id"] = PROJECT["id"] + ("-MDF" if ext == "xlsx" else "-GDE")
    files["list"].append(entry)
    files["data"][name] = base64.b64encode(raw).decode()
j = lambda o: json.dumps(o, ensure_ascii=False).replace("</", "<\\/")
html = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "portal_template.html"), encoding="utf-8").read()
html = html.replace("__DATA__", j(data)).replace("__FILES__", j(files))
open(out, "w", encoding="utf-8").write(html)
print(f"{out}: {len(html)/1e6:.2f} MB, {len(files['list'])} files")
